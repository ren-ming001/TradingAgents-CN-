"""
Core module for TradingAgents FastAPI backend
"""