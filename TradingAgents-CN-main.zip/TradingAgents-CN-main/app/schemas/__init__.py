"""
Pydantic schemas for API request/response models
"""