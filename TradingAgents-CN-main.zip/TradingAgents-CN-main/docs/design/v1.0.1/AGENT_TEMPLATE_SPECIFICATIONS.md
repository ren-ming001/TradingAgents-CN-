# Agent提示词模版规范

## 📋 13个Agent的模版规范

### 1️⃣ 基本面分析师 (fundamentals_analyst)

**角色**: 数据收集型分析师
**工具**: get_stock_fundamentals_unified
**输出**: 基本面分析报告

**模版变量**:
- {ticker}, {company_name}, {market_name}, {currency_name}, {currency_symbol}
- {current_date}

**模版类型**:
- **default**: 标准基本面分析
- **conservative**: 保守估值分析，强调风险
- **aggressive**: 激进成长分析，强调机会

**关键要求**:
- 必须调用工具获取数据
- 提供财务数据分析
- 提供估值指标分析
- 使用正确的货币单位

---

### 2️⃣ 市场分析师 (market_analyst)

**角色**: 数据收集型分析师
**工具**: get_stock_market_data_unified
**输出**: 技术分析报告

**模版变量**:
- {ticker}, {company_name}, {market_name}, {currency_symbol}
- {current_date}, {start_date}, {end_date}

**模版类型**:
- **default**: 标准技术分析
- **short_term**: 短期交易分析，关注日线/周线
- **long_term**: 长期趋势分析，关注月线/年线

**关键要求**:
- 必须调用工具获取市场数据
- 分析技术指标
- 识别支撑/阻力位
- 提供趋势判断

---

### 3️⃣ 新闻分析师 (news_analyst)

**角色**: 数据收集型分析师
**工具**: get_stock_news_unified
**输出**: 新闻影响分析报告

**模版变量**:
- {ticker}, {company_name}, {market_name}
- {current_date}

**模版类型**:
- **default**: 标准新闻分析
- **real_time**: 实时新闻快速分析
- **deep**: 深度新闻影响分析

**关键要求**:
- 必须调用工具获取新闻
- 分析新闻对股价的影响
- 评估新闻的重要性
- 提供市场反应预测

---

### 4️⃣ 社媒分析师 (social_media_analyst)

**角色**: 数据收集型分析师
**工具**: get_stock_sentiment_unified
**输出**: 情绪分析报告

**模版变量**:
- {ticker}, {company_name}, {market_name}
- {current_date}

**模版类型**:
- **default**: 标准情绪分析
- **sentiment_focus**: 情绪导向分析，强调情绪指标
- **trend_focus**: 趋势导向分析，强调趋势变化

**关键要求**:
- 必须调用工具获取情绪数据
- 分析社交媒体情绪
- 评估情绪强度
- 预测情绪变化趋势

---

### 5️⃣ 看涨研究员 (bull_researcher)

**角色**: 分析型研究员
**输入**: 4个分析报告 + 辩论历史
**输出**: 看涨论点

**模版变量**:
- {ticker}, {company_name}, {market_name}, {currency_name}, {currency_symbol}
- {market_report}, {sentiment_report}, {news_report}, {fundamentals_report}
- {history}, {current_response}

**模版类型**:
- **default**: 标准看涨分析
- **optimistic**: 乐观看涨分析，强调机会
- **moderate**: 温和看涨分析，平衡风险

**关键要求**:
- 基于提供的报告进行分析
- 提出合理的看涨论点
- 反驳看跌观点
- 参与辩论讨论

---

### 6️⃣ 看跌研究员 (bear_researcher)

**角色**: 分析型研究员
**输入**: 4个分析报告 + 辩论历史
**输出**: 看跌论点

**模版变量**:
- {ticker}, {company_name}, {market_name}, {currency_name}, {currency_symbol}
- {market_report}, {sentiment_report}, {news_report}, {fundamentals_report}
- {history}, {current_response}

**模版类型**:
- **default**: 标准看跌分析
- **pessimistic**: 悲观看跌分析，强调风险
- **moderate**: 温和看跌分析，平衡机会

**关键要求**:
- 基于提供的报告进行分析
- 提出合理的看跌论点
- 反驳看涨观点
- 参与辩论讨论

---

### 7️⃣ 激进辩手 (aggressive_debator)

**角色**: 评估型辩手
**输入**: 交易员决策 + 4个分析报告 + 辩论历史
**输出**: 激进风险评估

**模版变量**:
- {ticker}, {company_name}, {market_name}
- {trader_decision}, {market_report}, {sentiment_report}, {news_report}, {fundamentals_report}
- {history}, {current_risky_response}, {current_neutral_response}

**模版类型**:
- **default**: 标准激进评估
- **extreme**: 极端激进评估，强调机会最大化

**关键要求**:
- 评估交易员决策的风险
- 提出激进的替代方案
- 反驳保守观点
- 强调收益潜力

---

### 8️⃣ 保守辩手 (conservative_debator)

**角色**: 评估型辩手
**输入**: 交易员决策 + 4个分析报告 + 辩论历史
**输出**: 保守风险评估

**模版变量**:
- {ticker}, {company_name}, {market_name}
- {trader_decision}, {market_report}, {sentiment_report}, {news_report}, {fundamentals_report}
- {history}, {current_risky_response}, {current_neutral_response}

**模版类型**:
- **default**: 标准保守评估
- **cautious**: 谨慎保守评估，强调风险最小化

**关键要求**:
- 评估交易员决策的风险
- 提出保守的替代方案
- 反驳激进观点
- 强调风险缓解

---

### 9️⃣ 中立辩手 (neutral_debator)

**角色**: 评估型辩手
**输入**: 交易员决策 + 4个分析报告 + 辩论历史
**输出**: 中立风险评估

**模版变量**:
- {ticker}, {company_name}, {market_name}
- {trader_decision}, {market_report}, {sentiment_report}, {news_report}, {fundamentals_report}
- {history}, {current_risky_response}, {current_safe_response}

**模版类型**:
- **default**: 标准中立评估
- **balanced**: 平衡中立评估，强调风险收益平衡

**关键要求**:
- 评估交易员决策的风险
- 提出平衡的替代方案
- 平衡激进和保守观点
- 强调风险收益平衡

---

### 🔟 研究经理 (research_manager)

**角色**: 决策型管理者
**输入**: 4个分析报告 + 辩论历史
**输出**: 投资决策 + 投资计划

**模版变量**:
- {ticker}, {company_name}, {market_name}, {currency_name}, {currency_symbol}
- {market_report}, {sentiment_report}, {news_report}, {fundamentals_report}
- {history}

**模版类型**:
- **default**: 标准决策制定
- **strict**: 严格决策制定，要求更高的证据标准

**关键要求**:
- 综合分析所有报告
- 做出明确的买入/卖出/持有决策
- 提供具体的目标价格
- 制定详细的投资计划

---

### 1️⃣1️⃣ 风险经理 (risk_manager)

**角色**: 决策型管理者
**输入**: 交易员决策 + 4个分析报告 + 风险辩论历史
**输出**: 风险评估 + 最终决策

**模版变量**:
- {ticker}, {company_name}, {market_name}, {currency_name}, {currency_symbol}
- {trader_decision}, {market_report}, {sentiment_report}, {news_report}, {fundamentals_report}
- {history}

**模版类型**:
- **default**: 标准风险评估
- **strict**: 严格风险评估，要求更高的风险标准

**关键要求**:
- 评估交易员决策的风险
- 综合激进/保守/中立观点
- 做出最终的风险决策
- 提供风险缓解建议

---

### 1️⃣2️⃣ 交易员 (trader)

**角色**: 决策型交易员
**输入**: 投资计划 + 4个分析报告
**输出**: 交易决策 + 目标价格

**模版变量**:
- {ticker}, {company_name}, {market_name}, {currency_name}, {currency_symbol}
- {investment_plan}, {market_report}, {sentiment_report}, {news_report}, {fundamentals_report}

**模版类型**:
- **default**: 标准交易决策
- **conservative**: 保守交易决策，强调风险控制
- **aggressive**: 激进交易决策，强调收益最大化

**关键要求**:
- 基于投资计划做出交易决策
- 提供具体的目标价格（必须）
- 提供置信度评分
- 提供风险评分

---

## 📊 模版统计

| 类别 | Agent数 | 总模版数 | 平均模版数 |
|------|---------|---------|-----------|
| 分析师 | 4 | 12 | 3 |
| 研究员 | 2 | 6 | 3 |
| 辩手 | 3 | 6 | 2 |
| 管理者 | 2 | 4 | 2 |
| 交易员 | 1 | 3 | 3 |
| **总计** | **12** | **31** | **2.6** |

---

## 🔄 模版继承关系

```
基础模版 (base_template.yaml)
├── 分析师模版
│   ├── fundamentals_analyst
│   ├── market_analyst
│   ├── news_analyst
│   └── social_media_analyst
├── 研究员模版
│   ├── bull_researcher
│   └── bear_researcher
├── 辩手模版
│   ├── aggressive_debator
│   ├── conservative_debator
│   └── neutral_debator
├── 管理者模版
│   ├── research_manager
│   └── risk_manager
└── 交易员模版
    └── trader
```

---

## 💡 最佳实践

1. **模版命名**: 使用清晰的英文名称
2. **文档注释**: 在模版中清楚说明用途
3. **变量使用**: 只使用定义的标准变量
4. **版本管理**: 保留模版历史便于回滚
5. **测试验证**: 创建模版后进行充分测试

