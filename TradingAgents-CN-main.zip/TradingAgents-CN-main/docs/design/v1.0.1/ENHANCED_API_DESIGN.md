# 增强型API设计 - 用户、偏好、历史记录

## 📋 概述

本文档设计提示词模板系统的完整API接口，包括用户管理、分析偏好、模板管理和历史记录功能。

---

## 👥 用户管理API

### 1. 创建用户
```
POST /api/v1/users
Content-Type: application/json

{
    "username": "john_doe",
    "email": "john@example.com"
}

Response 201:
{
    "user_id": "uuid",
    "username": "john_doe",
    "email": "john@example.com",
    "created_at": "2025-01-15T10:00:00Z"
}
```

### 2. 获取用户信息
```
GET /api/v1/users/{user_id}

Response 200:
{
    "user_id": "uuid",
    "username": "john_doe",
    "email": "john@example.com",
    "created_at": "2025-01-15T10:00:00Z",
    "preferences": [...],
    "template_configs": [...]
}
```

### 3. 更新用户信息
```
PUT /api/v1/users/{user_id}
Content-Type: application/json

{
    "username": "john_doe_updated",
    "email": "john_new@example.com"
}

Response 200: 更新后的用户信息
```

### 4. 删除用户
```
DELETE /api/v1/users/{user_id}

Response 204: No Content
```

---

## 🎯 分析偏好API

### 1. 创建偏好
```
POST /api/v1/users/{user_id}/preferences
Content-Type: application/json

{
    "preference_type": "conservative",
    "description": "保守型投资偏好",
    "risk_level": 0.3,
    "confidence_threshold": 0.8,
    "position_size_multiplier": 0.5,
    "decision_speed": "slow",
    "is_default": true
}

Response 201:
{
    "preference_id": "uuid",
    "user_id": "uuid",
    "preference_type": "conservative",
    "description": "保守型投资偏好",
    "risk_level": 0.3,
    "confidence_threshold": 0.8,
    "position_size_multiplier": 0.5,
    "decision_speed": "slow",
    "is_default": true,
    "created_at": "2025-01-15T10:00:00Z"
}
```

### 2. 获取用户所有偏好
```
GET /api/v1/users/{user_id}/preferences

Response 200:
{
    "preferences": [
        {
            "preference_id": "uuid",
            "preference_type": "aggressive",
            ...
        },
        {
            "preference_id": "uuid",
            "preference_type": "neutral",
            ...
        },
        {
            "preference_id": "uuid",
            "preference_type": "conservative",
            ...
        }
    ]
}
```

### 3. 获取特定偏好
```
GET /api/v1/users/{user_id}/preferences/{preference_id}

Response 200: 偏好详情
```

### 4. 更新偏好
```
PUT /api/v1/users/{user_id}/preferences/{preference_id}
Content-Type: application/json

{
    "description": "更新的描述",
    "risk_level": 0.4,
    "is_default": true
}

Response 200: 更新后的偏好
```

### 5. 删除偏好
```
DELETE /api/v1/users/{user_id}/preferences/{preference_id}

Response 204: No Content
```

### 6. 设置默认偏好
```
POST /api/v1/users/{user_id}/preferences/{preference_id}/set-default

Response 200:
{
    "message": "Default preference set successfully",
    "preference_id": "uuid"
}
```

---

## 📝 模板管理API

### 1. 获取用户模板配置
```
GET /api/v1/users/{user_id}/template-configs

Response 200:
{
    "configs": [
        {
            "config_id": "uuid",
            "agent_type": "analysts",
            "agent_name": "fundamentals_analyst",
            "template_id": "uuid",
            "preference_id": "uuid",
            "is_active": true,
            "created_at": "2025-01-15T10:00:00Z"
        }
    ]
}
```

### 2. 设置用户模板
```
POST /api/v1/users/{user_id}/template-configs
Content-Type: application/json

{
    "agent_type": "analysts",
    "agent_name": "fundamentals_analyst",
    "template_id": "uuid",
    "preference_id": "uuid"
}

Response 201: 配置详情
```

### 3. 更新用户模板配置
```
PUT /api/v1/users/{user_id}/template-configs/{config_id}
Content-Type: application/json

{
    "template_id": "new_uuid",
    "is_active": true
}

Response 200: 更新后的配置
```

### 4. 删除用户模板配置
```
DELETE /api/v1/users/{user_id}/template-configs/{config_id}

Response 204: No Content
```

---

## 📚 模板历史API

### 1. 获取模板历史
```
GET /api/v1/templates/{template_id}/history

Query Parameters:
- page: 1
- page_size: 20
- sort_by: created_at (desc)

Response 200:
{
    "history": [
        {
            "history_id": "uuid",
            "template_id": "uuid",
            "version": 3,
            "change_description": "Updated analysis criteria",
            "change_type": "update",
            "created_by": "user_uuid",
            "created_at": "2025-01-15T10:00:00Z"
        }
    ],
    "total": 10,
    "page": 1,
    "page_size": 20
}
```

### 2. 获取特定版本
```
GET /api/v1/templates/{template_id}/history/{version}

Response 200:
{
    "history_id": "uuid",
    "template_id": "uuid",
    "version": 2,
    "content": "...",
    "change_description": "Initial version",
    "change_type": "create",
    "created_by": "user_uuid",
    "created_at": "2025-01-15T10:00:00Z"
}
```

### 3. 恢复到特定版本
```
POST /api/v1/templates/{template_id}/restore/{version}
Content-Type: application/json

{
    "reason": "Restore to previous working version"
}

Response 200:
{
    "message": "Template restored successfully",
    "new_version": 4,
    "restored_from_version": 2
}
```

### 4. 对比两个版本
```
POST /api/v1/templates/{template_id}/compare
Content-Type: application/json

{
    "version_1": 2,
    "version_2": 3
}

Response 200:
{
    "comparison_id": "uuid",
    "template_id": "uuid",
    "version_1": 2,
    "version_2": 3,
    "differences": [
        {
            "field": "system_prompt",
            "old_value": "...",
            "new_value": "...",
            "change_type": "modified"
        }
    ],
    "created_at": "2025-01-15T10:00:00Z"
}
```

### 5. 获取对比历史
```
GET /api/v1/users/{user_id}/template-comparisons

Query Parameters:
- page: 1
- page_size: 20

Response 200:
{
    "comparisons": [
        {
            "comparison_id": "uuid",
            "template_id": "uuid",
            "version_1": 2,
            "version_2": 3,
            "created_at": "2025-01-15T10:00:00Z"
        }
    ],
    "total": 5,
    "page": 1
}
```

---

## 🔄 增强的模板API

### 1. 创建自定义模板
```
POST /api/v1/templates
Content-Type: application/json

{
    "user_id": "uuid",
    "agent_type": "analysts",
    "agent_name": "fundamentals_analyst",
    "template_name": "my_custom_template",
    "preference_type": "conservative",
    "content": {
        "system_prompt": "...",
        "tool_guidance": "...",
        "analysis_requirements": "...",
        "output_format": "...",
        "constraints": "..."
    },
    "status": "active"  // 'draft'                  
}

Response 201:
{
    "template_id": "uuid",
    "version": 1,
    "status": "active",
    "created_at": "2025-01-15T10:00:00Z"
}
```

### 2. 更新模板
```
PUT /api/v1/templates/{template_id}
Content-Type: application/json

{
    "user_id": "uuid",
    "content": {...},
    "change_description": "Updated analysis criteria",
    "status": "active"  //                 
}

Response 200:
{
    "template_id": "uuid",
    "version": 2,
    "status": "active",
    "updated_at": "2025-01-15T10:00:00Z"
}
```

### 3. 获取用户的所有自定义模板
```
GET /api/v1/users/{user_id}/custom-templates

Query Parameters:
- agent_type: analysts (optional)
- preference_type: conservative (optional)
- page: 1
- page_size: 20

Response 200:
{
    "templates": [
        {
            "template_id": "uuid",
            "agent_type": "analysts",
            "agent_name": "fundamentals_analyst",
            "template_name": "my_custom_template",
            "preference_type": "conservative",
            "created_at": "2025-01-15T10:00:00Z",
            "updated_at": "2025-01-15T10:00:00Z"
        }
    ],
    "total": 5,
    "page": 1
}
```

### 4. 克隆模板
```
POST /api/v1/templates/{template_id}/clone
Content-Type: application/json

{
    "user_id": "uuid",
    "new_template_name": "cloned_template"
}

Response 201:
{
    "template_id": "new_uuid",
    "template_name": "cloned_template",
    "version": 1,
    "created_at": "2025-01-15T10:00:00Z"
}
```

---

## 📊 查询和统计API

### 1. 获取用户统计
```
GET /api/v1/users/{user_id}/statistics

Response 200:
{
    "user_id": "uuid",
    "total_preferences": 3,
    "total_custom_templates": 5,
    "total_template_versions": 12,
    "total_comparisons": 3,
    "last_modified": "2025-01-15T10:00:00Z"
}
```

### 2. 获取模板使用统计
```
GET /api/v1/templates/{template_id}/statistics

Response 200:
{
    "template_id": "uuid",
    "total_versions": 5,
    "total_users": 3,
    "total_comparisons": 2,
    "last_modified": "2025-01-15T10:00:00Z",
    "most_used_version": 3
}
```

### 3. 获取偏好使用统计
```
GET /api/v1/users/{user_id}/preferences/{preference_id}/statistics

Response 200:
{
    "preference_id": "uuid",
    "total_agents_using": 4,
    "total_templates": 2,
    "created_at": "2025-01-15T10:00:00Z",
    "last_used": "2025-01-15T10:00:00Z"
}
```

---

## 🔐 认证和授权

### 认证头
```
Authorization: Bearer {token}
```

### 权限检查
- 用户只能访问自己的数据
- 管理员可以访问所有数据
- 系统模板只读

---

## 📈 错误处理

### 常见错误码
- 400: 请求参数错误
- 401: 未认证
- 403: 无权限
- 404: 资源不存在
- 409: 冲突 (如重复的偏好类型)
- 500: 服务器错误

### 错误响应格式
```json
{
    "error": {
        "code": "INVALID_REQUEST",
        "message": "Invalid request parameters",
        "details": {...}
    }
}
```

---

## 🚀 实现优先级

### 高优先级 (Phase 1-2)
- 用户管理API
- 分析偏好API
- 模板配置API

### 中优先级 (Phase 3-4)
- 模板历史API
- 版本对比API
- 版本恢复API

### 低优先级 (Phase 5)
- 统计API
- 克隆API
- 高级查询API

---

**版本**: v1.0.1  
**状态**: 设计完成  
**下一步**: 实现API接口

